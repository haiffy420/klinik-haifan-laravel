<?php

namespace App\Tables\Columns;

use Filament\Tables\Columns\Column;

class EarningsColumn extends Column
{
    protected string $view = 'tables.columns.earnings-column';
}
