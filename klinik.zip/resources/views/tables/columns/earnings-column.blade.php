<div class="fi-ta-text-item inline-flex items-center gap-1.5 text-sm text-gray-950 dark:text-white" style="padding-left:0.8rem">
    <p>Rp. {{ calculateEarnings($getRecord) }}</p>
</div>
