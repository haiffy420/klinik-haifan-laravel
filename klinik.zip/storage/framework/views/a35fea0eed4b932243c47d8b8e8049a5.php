<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($fileName); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->

    <style>
        body {
            font-family: 'Nunito', sans-serif;
        }

        p {
            margin-bottom: -13px
        }

        span {
            font-weight: bold;
        }
    </style>
    <style>
        .demo {
            border: 1px solid #050505;
            border-collapse: collapse;
            padding: 5px;
        }

        .demo th {
            border: 1px solid #050505;
            padding: 5px;
            background: #A39F9F;
        }

        .demo td {
            border: 1px solid #050505;
            text-align: center;
            padding: 5px;
        }
    </style>

</head>

<body class="antialiased">
    <h2 style="margin: -2px;"><?php echo e($prescription->patient->user->name); ?></h2>
    <hr style="border: 1px solid">
    <table width="100%" border="0" style="margin:20px 0">
        <tr style="vertical-align: top;">
            <td width="100">Pasien</td>
            <td width="1">:</td>
            <td><?php echo e($prescription->patient->user->name); ?> <br> <?php echo e($prescription->patient->user->address); ?></td>
        </tr>
        <tr>
            <td width="100">Tanggal</td>=>
            <td>:</td>
            <td><?php echo e($prescription->prescription_date); ?></td>
        </tr>
    </table>

    <table width="100%" class="demo">
        <thead>
            <tr>
                <th width="50%">Nama Obat</th>
                <th width="15%">Harga</th>
                <th width="10%">Qty</th>
                <th width="15%">Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $prescription->prescribedDrugs->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->drugs->name); ?></td>
                    <td>Rp. <?php echo e(number_format($item->drugs->price, 0, ',', '.')); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>Rp. <?php echo e(number_format($item->drugs->price * $item->quantity, 0, ',', '.')); ?></td>
                    <?php $total += $item->drugs->price * $item->quantity; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3">Total</td>
                <td>Rp. <?php echo e(number_format($total, 0, ',', '.')); ?></td>
            </tr>
        </tbody>
    </table>

    <p>&nbsp;Terimakasih.</p>
    

    <table width="100%" border="0" style="margin:5px 0">
        <tr>
            <td>
                <h4 style="margin-bottom: 0">Informasi Dokter:</h4>
            </td>
        </tr>
        <tr>
            <td><?php echo e($prescription->doctor->user->name); ?></td>
        </tr>
        <tr>
            <td><?php echo e($prescription->doctor->user->email); ?></td>
        </tr>
        <tr>
            <td><?php echo e($prescription->doctor->user->contact_number); ?></td>
        </tr>
    </table>
    
</body>

</html>
<?php /**PATH C:\xampp\htdocs\klinik\resources\views/print.blade.php ENDPATH**/ ?>